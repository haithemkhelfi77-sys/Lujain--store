const V='lujain-v1',SHELL=['/','/index.html','/css/style.css','/js/app.js','/js/services.js','/js/config.js','/assets/icons/icon.svg','/pages/offline.html'];
self.addEventListener('install',e=>e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!=V).map(x=>caches.delete(x)))).then(()=>clients.claim())));
self.addEventListener('fetch',e=>{const r=e.request,u=new URL(r.url);
 if(r.method!='GET'||u.origin!=location.origin||u.pathname.startsWith('/admin'))return; // لا تخزين للطلبات الخارجية (Firebase) ولا للإدارة
 if(r.mode=='navigate')return e.respondWith(fetch(r).catch(()=>caches.match('/pages/offline.html')));
 e.respondWith(caches.match(r).then(h=>h||fetch(r).then(x=>{const c=x.clone();caches.open(V).then(ch=>ch.put(r,c));return x})))});
