# Lujain Store (تجهيز الربط مع Firebase Firestore)

المشروع مجهّز على خطة Spark المجانية مع الإبقاء على `CONFIG.firebase = null` في هذه المرحلة.
