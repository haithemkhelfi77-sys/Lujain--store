import {CONFIG} from './config.js';
import * as S from './services.js';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const fmt=n=>n.toLocaleString('ar-DZ')+' '+CONFIG.currency;
const price=p=>p.sale>0?p.sale:p.price;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const img=(p,i=0)=>`data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 500"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${p.c1}"/><stop offset="1" stop-color="#000" stop-opacity=".55"/></linearGradient></defs><rect width="400" height="500" fill="url(#g)"/><circle cx="${200+i*30}" cy="230" r="${90-i*10}" fill="${p.c2}" opacity=".9"/><rect x="${150+i*20}" y="300" width="100" height="14" rx="7" fill="${p.c2}" opacity=".5"/></svg>`)}`;
let products=[],cart=JSON.parse(localStorage.getItem('lp_cart')||'[]'),fav=JSON.parse(localStorage.getItem('lp_fav')||'[]'),state={q:'',cat:'',sort:'new',max:0,page:1};
const save=()=>{localStorage.setItem('lp_cart',JSON.stringify(cart));localStorage.setItem('lp_fav',JSON.stringify(fav));$('#cartCount').textContent=cart.reduce((a,c)=>a+c.qty,0);$('#favCount').textContent=fav.length};
function toast(m,t='ok'){const e=document.createElement('div');e.className='toast '+t;e.textContent=m;$('#toasts').append(e);setTimeout(()=>e.remove(),3200)}
const open=id=>{$$('.sheet').forEach(s=>s.classList.remove('on'));$(id).classList.add('on');$('#scrim').classList.add('on')};
const close=()=>{$$('.sheet').forEach(s=>s.classList.remove('on'));$('#scrim').classList.remove('on')};
function card(p){const off=p.sale>0?Math.round(100-p.sale/p.price*100):0;return`<article class="card" data-id="${p.id}"><div class="ph"><img loading="lazy" src="${img(p)}" alt="${esc(p.name)}">${off?`<b class="tag">-${off}%</b>`:''}${p.demo?'<i class="demo">تجريبي</i>':''}<button class="fav ${fav.includes(p.id)?'on':''}" data-fav="${p.id}" aria-label="المفضلة">♥</button></div><h3>${esc(p.name)}</h3><p class="rt">★ ${p.rating} · ${esc(p.cat)}</p><p class="pr">${fmt(price(p))} ${off?`<s>${fmt(p.price)}</s>`:''}</p><button class="btn" data-add="${p.id}" ${p.stock<1?'disabled':''}>${p.stock<1?'نفدت الكمية':'أضف إلى السلة'}</button></article>`}
function render(){let r=products.filter(p=>(!state.cat||p.cat==state.cat)&&p.name.includes(state.q)&&(!state.max||price(p)<=state.max));
 r.sort({new:(a,b)=>b.created-a.created,lo:(a,b)=>price(a)-price(b),hi:(a,b)=>price(b)-price(a),pop:(a,b)=>b.rating-a.rating}[state.sort]);
 const n=state.page*8;$('#grid').innerHTML=r.slice(0,n).map(card).join('')||'<p class="empty">لا توجد منتجات مطابقة. جرّب تغيير البحث أو الفلاتر.</p>';$('#more').hidden=r.length<=n}
function renderCart(){
 cart=cart.filter(c=>{const p=products.find(x=>x.id==c.id);return p&&p.stock>0&&c.qty>0}).map(c=>{const p=products.find(x=>x.id==c.id);return{...c,qty:Math.min(c.qty,p.stock)}});
 const sub=cart.reduce((a,c)=>{const p=products.find(x=>x.id==c.id);return a+(p?price(p)*c.qty:0)},0),ship=!cart.length||sub>=CONFIG.freeShippingFrom?0:CONFIG.shipping;
 $('#cartBody').innerHTML=cart.map(c=>{const p=products.find(x=>x.id==c.id);return p?`<div class="line"><img src="${img(p)}" alt=""><div><b>${esc(p.name)}</b><span>${fmt(price(p))}</span><div class="qty"><button data-q="${p.id}" data-d="-1">−</button>${c.qty}<button data-q="${p.id}" data-d="1">+</button></div></div><button data-rm="${p.id}" aria-label="حذف">×</button></div>`:''}).join('')||'<p class="empty">سلتك فارغة. اكتشف المنتجات وأضف ما يعجبك.</p>';
 $('#sum').innerHTML=`<p>المجموع <b>${fmt(sub)}</b></p><p>الشحن <b>${ship?fmt(ship):'مجاني'}</b></p><p class="tot">الإجمالي <b>${fmt(sub+ship)}</b></p>`;$('#toCheckout').disabled=!cart.length;return{sub,ship}}
function add(id,q=1){const p=products.find(x=>x.id==id),c=cart.find(x=>x.id==id);if(!p||p.stock<1)return toast('المنتج غير متوفر حالياً','err');const n=(c?.qty||0)+q;if(n>p.stock)return toast('الكمية المتاحة '+p.stock+' فقط','err');c?c.qty=n:cart.push({id,qty:q});save();renderCart();$('#cartBtn').classList.remove('bump');void $('#cartBtn').offsetWidth;$('#cartBtn').classList.add('bump');toast('تمت الإضافة إلى السلة')}
function detail(id){const p=products.find(x=>x.id==id),sim=products.filter(x=>x.cat==p.cat&&x.id!=id).slice(0,3);
 $('#detail').innerHTML=`<button class="x" data-close>×</button><div class="gal"><img id="big" src="${img(p)}" alt="${esc(p.name)}">${[0,1,2].map(i=>`<img class="th" data-th="${img(p,i)}" src="${img(p,i)}" alt="">`).join('')}</div><h2>${esc(p.name)}</h2><p class="rt">★ ${p.rating} · ${p.stock<1?'غير متوفر':p.stock<=CONFIG.lowStock?'متبقي '+p.stock+' فقط':'متوفر'}</p><p class="pr">${fmt(price(p))} ${p.sale>0?`<s>${fmt(p.price)}</s>`:''}</p><p>${esc(p.desc)}</p><p class="note">شحن خلال 2–5 أيام · استرجاع خلال 7 أيام</p><div class="qty"><button id="dqm">−</button><span id="dq">1</span><button id="dqp">+</button></div><button class="btn solid" id="dadd" ${p.stock<1?'disabled':''}>أضف إلى السلة</button><h4>منتجات مشابهة</h4><div class="mini">${sim.map(s=>`<a href="#" data-open="${s.id}"><img src="${img(s)}" alt="${esc(s.name)}"></a>`).join('')}</div>`;
 let q=1;$('#dqp').onclick=()=>{q=Math.min(Math.max(1,p.stock),q+1);$('#dq').textContent=q};$('#dqm').onclick=()=>{q=Math.max(1,q-1);$('#dq').textContent=q};$('#dadd').onclick=()=>{if(p.stock<1)return toast('المنتج غير متوفر حالياً','err');add(id,q);close()};open('#detail')}
const rules={name:v=>v.trim().length>=3||'أدخل الاسم الكامل',phone:v=>/^(0|\+213)[5-7]\d{8}$/.test(v.replace(/\s/g,''))||'رقم هاتف غير صالح',wilaya:v=>v.trim().length>=2||'أدخل الولاية',city:v=>v.trim().length>=2||'أدخل البلدية',address:v=>v.trim().length>=8||'أدخل عنواناً مفصلاً'};
async function checkout(e){e.preventDefault();const f=Object.fromEntries(new FormData(e.target));let ok=true;
 for(const k in rules){const r=rules[k](f[k]||'');$(`[data-err=${k}]`).textContent=r===true?'':r;if(r!==true)ok=false}
 if(!ok)return toast('راجع الحقول المحددة','err');
 let preview;try{preview=S.computeOrderPreview(cart,products)}catch(err){return toast(err.message||'تحقق من كميات السلة','err')}
 const b=e.target.querySelector('button.solid');b.disabled=true;b.textContent='جارٍ الإرسال…';
 try{const r=await S.submitOrder({customer:f,items:preview.items,subtotal:preview.subtotal,shipping:preview.shipping,total:preview.total});
  cart=[];save();renderCart();close();e.target.reset();toast(r.sent?'تم إرسال طلبك رقم '+r.id:'طلب اختبار محلي '+r.id+' — لم يُرسل إلى أي خادم',r.sent?'ok':'warn')}
 catch(x){toast(x.message||'فشل الإرسال، حاول لاحقاً','err')}finally{b.disabled=false;b.textContent='تأكيد الطلب'}}
async function account(e){e.preventDefault();const f=Object.fromEntries(new FormData(e.target)),m=e.submitter.value;
 if(!S.isLive())return toast('المصادقة غير مفعّلة: أضف إعدادات Firebase في js/config.js','warn');
 try{if(m=='in')await S.auth.signIn(f.email,f.pass);if(m=='up')await S.auth.signUp(f.email,f.pass);if(m=='reset')await S.auth.reset(f.email);toast('تمت العملية بنجاح');if(m!='reset')close()}catch(x){toast('تعذّرت العملية: '+(x.code||x.message),'err')}}
async function init(){
 $('#grid').innerHTML='<div class="sk"></div>'.repeat(4);try{products=await S.listProducts()}catch{toast('تعذّر تحميل المنتجات','err')}
 $('#cats').innerHTML=['',...new Set(products.map(p=>p.cat))].map(c=>`<button data-cat="${c}" class="${c?'':'on'}">${c||'الكل'}</button>`).join('');
 $('#strip').textContent=S.isLive()?'شحن مجاني للطلبات فوق '+fmt(CONFIG.freeShippingFrom):'وضع تجريبي: بيانات تجريبية وطلبات محلية فقط';
 save();render();renderCart();
 document.addEventListener('click',e=>{const t=e.target,g=a=>t.closest(`[${a}]`)?.getAttribute(a);
  if(g('data-add'))add(g('data-add'));else if(g('data-fav')){const id=g('data-fav');fav=fav.includes(id)?fav.filter(x=>x!=id):[...fav,id];save();render()}
  else if(g('data-cat')!=null){state.cat=g('data-cat');state.page=1;$$('#cats button').forEach(b=>b.classList.toggle('on',b.dataset.cat==state.cat));render()}
  else if(g('data-q')){const c=cart.find(x=>x.id==g('data-q')),p=products.find(x=>x.id==c.id),n=c.qty+ +g('data-d');if(n<1)cart=cart.filter(x=>x!=c);else if(n>p.stock)return toast('الكمية المتاحة '+p.stock+' فقط','err');else c.qty=n;save();renderCart()}
  else if(g('data-rm')){cart=cart.filter(x=>x.id!=g('data-rm'));save();renderCart()}
  else if(g('data-th'))$('#big').src=g('data-th');
  else if(g('data-open')){e.preventDefault();detail(g('data-open'))}
  else if(t.closest('.card')&&!t.closest('button')){detail(t.closest('.card').dataset.id)}
  else if(g('data-sheet'))open(g('data-sheet'));else if(t.closest('[data-close]')||t.id=='scrim')close()});
 $('#q').oninput=e=>{state.q=e.target.value.trim();state.page=1;render()};$('#sort').onchange=e=>{state.sort=e.target.value;render()};
 $('#max').onchange=e=>{state.max=+e.target.value;render()};$('#more').onclick=()=>{state.page++;render()};
 $('#toCheckout').onclick=()=>open('#checkout');$('#coForm').onsubmit=checkout;$('#acForm').onsubmit=account;
 $('#nl').onsubmit=e=>{e.preventDefault();toast('الاشتراك يتطلب ربط خدمة بريد؛ لم يُحفظ بريدك','warn')};
 if('serviceWorker'in navigator)navigator.serviceWorker.register('/service-worker.js').catch(()=>{})}
init();
