// ضع إعدادات Firebase (Web App config) هنا — هي معرّفات عامة وليست أسراراً. اتركها null للوضع المحلي.
export const CONFIG = {
  firebase: null,
  firebaseVersion: '10.12.2',
  currency: 'د.ج',
  shipping: 600,
  freeShippingFrom: 15000,
  lowStock: 5,
  gaId: null,
  // بيانات مرجعية للتجهيز فقط (لا تفعّل الاتصال بمفردها طالما firebase: null)
  projectId: 'lujain-store-c6753',
  firestoreRegion: 'europe-west9'
};
