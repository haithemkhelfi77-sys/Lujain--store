// طبقة البيانات: كل العمليات تمر من هنا. بدّل المصدر بوضع CONFIG.firebase دون لمس الواجهات.
import {CONFIG} from './config.js';

const get = (k, d) => {
  try {
    return JSON.parse(localStorage.getItem(k)) ?? d;
  } catch {
    return d;
  }
};
const put = (k, v) => localStorage.setItem(k, JSON.stringify(v));

export const isLive = () => !!CONFIG.firebase;
export const isLocalDev = () => ['localhost', '127.0.0.1'].includes(location.hostname);

let fb;
async function F() {
  if (fb) return fb;
  const b = `https://www.gstatic.com/firebasejs/${CONFIG.firebaseVersion}/`;
  const [a, f, u] = await Promise.all([
    import(b + 'firebase-app.js'),
    import(b + 'firebase-firestore.js'),
    import(b + 'firebase-auth.js')
  ]);
  const app = a.initializeApp(CONFIG.firebase);
  return (fb = {f, u, db: f.getFirestore(app), auth: u.getAuth(app)});
}

export const SEED = [
  ['عطر عنبر الليل', 'عطور', 18000, 14400, 12, '#2b2f55', '#c9a45c'],
  ['ماء ورد ملكي', 'عطور', 9000, 0, 30, '#5a2a3a', '#e8b4b8'],
  ['ساعة كلاسيك فضية', 'ساعات', 42000, 35700, 4, '#1f2a37', '#cfd6dd'],
  ['ساعة جلدية رجالية', 'ساعات', 36000, 0, 9, '#3b2a1d', '#c08a4b'],
  ['حقيبة جلد يومية', 'حقائب', 28000, 22400, 7, '#2f4a3f', '#d8c9a3'],
  ['حقيبة سفر خفيفة', 'حقائب', 52000, 0, 0, '#40485a', '#aab4c8'],
  ['سوار ذهبي رفيع', 'إكسسوارات', 12000, 9600, 20, '#4a3a1d', '#e0b84f'],
  ['نظارة شمسية أنيقة', 'إكسسوارات', 15000, 0, 15, '#222', '#9bb7c7']
].map((p, i) => ({
  id: 'demo' + i,
  name: p[0],
  cat: p[1],
  price: p[2],
  sale: p[3],
  stock: p[4],
  c1: p[5],
  c2: p[6],
  rating: +(4 + ((i * 7) % 10) / 10).toFixed(1),
  published: true,
  featured: i < 4,
  best: i % 2 == 0,
  demo: true,
  created: i,
  desc: 'وصف تجريبي للمنتج. يُستبدل ببياناتك الحقيقية من لوحة الإدارة.'
}));

// يقرأ الزائر المنتجات المنشورة فقط عبر where('published', '==', true)؛
// ويستطيع المدير صاحب Custom Claim admin:true قراءة جميع المنتجات (عند طلب all=true).
// لا يفشل تحميل المتجر بسبب وجود منتجات غير منشورة أو عدم توفر صلاحية المدير للزائر.
export async function listProducts(all = false) {
  if (isLive()) {
    const {f, db, auth: a} = await F();
    const colRef = f.collection(db, 'products');
    let canReadAll = false;
    if (all && a.currentUser) {
      try {
        const token = await a.currentUser.getIdTokenResult();
        canReadAll = !!token?.claims?.admin;
      } catch {
        canReadAll = false;
      }
    }
    if (canReadAll) {
      try {
        const snap = await f.getDocs(colRef);
        return snap.docs.map(d => ({id: d.id, ...d.data()}));
      } catch {
        // تراجع آمن إلى استعلام المنتجات المنشورة فقط في حال رفض القواعد أو عدم تطابق الادعاء
      }
    }
    const pubQuery = f.query(colRef, f.where('published', '==', true));
    const pubSnap = await f.getDocs(pubQuery);
    return pubSnap.docs.map(d => ({id: d.id, ...d.data()}));
  }
  const r = get('lp_products', SEED);
  return all ? r : r.filter(p => p.published);
}

export async function saveProduct(p) {
  if (isLive()) {
    const {f, db} = await F();
    const {id, ...d} = p;
    if (id) await f.setDoc(f.doc(db, 'products', id), d);
    else await f.addDoc(f.collection(db, 'products'), d);
    return;
  }
  const r = get('lp_products', SEED);
  const i = r.findIndex(x => x.id == p.id);
  if (i < 0) r.push({...p, id: 'p' + Date.now()});
  else r[i] = p;
  put('lp_products', r);
}

export async function deleteProduct(id) {
  if (isLive()) {
    const {f, db} = await F();
    return f.deleteDoc(f.doc(db, 'products', id));
  }
  put('lp_products', get('lp_products', SEED).filter(x => x.id != id));
}

// فحص وجود مستند بالمعرّف الثابت (demo0..demo7) قبل أي استيراد؛ لا يُستدعى تلقائياً.
export async function checkSeedConflicts() {
  if (!isLive()) return {ok: false, reason: 'not_live', existingIds: [], missingIds: SEED.map(x => x.id)};
  if (!(await auth.isAdmin())) throw new Error('صلاحية المدير مطلوبة لفحص أو استيراد المنتجات.');
  const {f, db} = await F();
  const existingIds = [];
  const missingIds = [];
  for (const item of SEED) {
    const snap = await f.getDoc(f.doc(db, 'products', item.id));
    if (snap.exists()) existingIds.push(item.id);
    else missingIds.push(item.id);
  }
  return {ok: true, existingIds, missingIds};
}

// استيراد يدوي مضبوط للمنتجات الثابتة demo0..demo7 فقط بعد التحقق من صلاحية admin وفحص الوجود.
// لا يستبدل أو يدمج مستنداً موجوداً إلا إذا مرّر المستدعي confirmOverwriteIds صراحةً بعد تنبيه وموافقة صريحة.
export async function importSeedProducts({confirmOverwriteIds = []} = {}) {
  if (!isLive()) throw new Error('وضع Firebase غير مفعّل.');
  if (!(await auth.isAdmin())) throw new Error('مرفوض: الحساب لا يملك صلاحية admin.');
  const {f, db} = await F();
  const imported = [];
  const skippedExisting = [];

  for (const item of SEED) {
    const ref = f.doc(db, 'products', item.id);
    const snap = await f.getDoc(ref);
    const exists = snap.exists();
    if (exists && !confirmOverwriteIds.includes(item.id)) {
      skippedExisting.push(item.id);
      continue;
    }
    const {id, ...payload} = item;
    await f.setDoc(ref, payload);
    imported.push(id);
  }
  return {imported, skippedExisting};
}

// حساب مبدئي لخدمة واجهة المستخدم فقط؛ لا يُعدّ إثباتاً أمنياً ضد تزوير الطلبات بدون طبقة خادمة موثوقة.
export function computeOrderPreview(items, catalogProducts) {
  if (!Array.isArray(items) || !items.length) {
    throw new Error('السلة فارغة.');
  }
  const map = new Map((catalogProducts || []).map(p => [String(p.id), p]));
  const qtyById = new Map();
  for (const raw of items) {
    const id = String(raw?.id ?? '');
    const qty = Number(raw?.qty ?? 0);
    if (!id || !Number.isInteger(qty) || qty < 1) {
      throw new Error('كمية أو منتج غير صالح في الطلب.');
    }
    qtyById.set(id, (qtyById.get(id) || 0) + qty);
  }

  let subtotal = 0;
  const verifiedItems = [];
  for (const [id, qty] of qtyById.entries()) {
    const prod = map.get(id);
    if (!prod) throw new Error('أحد المنتجات غير موجود في الكتالوج.');
    if (prod.published === false) throw new Error('أحد المنتجات غير متاح حالياً.');
    const stock = Number(prod.stock ?? 0);
    if (stock < 1 || qty > stock) {
      throw new Error(`الكمية المطلوبة للمنتج "${prod.name}" تتجاوز المخزون المتاح (${stock}).`);
    }
    const basePrice = Number(prod.price);
    const salePrice = Number(prod.sale || 0);
    const unitPrice = salePrice > 0 && salePrice < basePrice ? salePrice : basePrice;
    if (!Number.isFinite(unitPrice) || unitPrice <= 0) {
      throw new Error('سعر المنتج غير صالح.');
    }
    subtotal += unitPrice * qty;
    verifiedItems.push({id: prod.id, qty, unitPrice});
  }

  const shipping = !verifiedItems.length || subtotal >= CONFIG.freeShippingFrom ? 0 : CONFIG.shipping;
  const total = subtotal + shipping;
  return {items: verifiedItems, subtotal, shipping, total};
}

// ملاحظة أمان: التحقق في JavaScript غير كافٍ لمنع تزوير الأسعار أو المخزون من عميل غير موثوق.
// بدون Firebase Storage ولا ترقية إلى Blaze (حيث Cloud Functions/Blaze غير مفعّلة في خطة Spark)،
// يُعلَّم الطلب المباشر من المتصفح كـ needsVerification:true ولا يُعتمد سعره أو مخزونه نهائياً إلا بعد مراجعة/تأكيد إداري أو خدمة موثوقة.
export async function submitOrder(o) {
  if (!navigator.onLine) throw new Error('لا يوجد اتصال بالإنترنت. لم يُرسل الطلب.');
  const catalog = await listProducts(true);
  const preview = computeOrderPreview(o?.items, catalog);
  const cleanOrder = {
    customer: o.customer,
    items: preview.items.map(({id, qty}) => ({id, qty})),
    clientSuggestedSubtotal: preview.subtotal,
    clientSuggestedShipping: preview.shipping,
    clientSuggestedTotal: preview.total,
    subtotal: preview.subtotal,
    shipping: preview.shipping,
    total: preview.total,
    needsVerification: true,
    verifiedByAdmin: false
  };

  if (isLive()) {
    const {f, db, auth: a} = await F();
    const ref = await f.addDoc(f.collection(db, 'orders'), {
      ...cleanOrder,
      uid: a.currentUser?.uid || null,
      status: 'new',
      createdAt: f.serverTimestamp()
    });
    return {id: ref.id, sent: true};
  }
  const r = get('lp_orders', []);
  const id = 'TEST-' + Date.now().toString().slice(-6);
  r.push({...cleanOrder, id, status: 'new', test: true, createdAt: Date.now()});
  put('lp_orders', r);
  return {id, sent: false};
}

export async function listOrders() {
  if (isLive()) {
    const {f, db} = await F();
    const s = await f.getDocs(f.collection(db, 'orders'));
    return s.docs.map(d => ({id: d.id, ...d.data()}));
  }
  return get('lp_orders', []);
}

export async function setOrderStatus(id, status) {
  if (isLive()) {
    const {f, db} = await F();
    return f.updateDoc(f.doc(db, 'orders', id), {status});
  }
  put('lp_orders', get('lp_orders', []).map(o => (o.id == id ? {...o, status} : o)));
}

export const auth = {
  async signIn(e, p) {
    const {u, auth: a} = await F();
    return u.signInWithEmailAndPassword(a, e, p);
  },
  async signUp(e, p) {
    const {u, auth: a} = await F();
    return u.createUserWithEmailAndPassword(a, e, p);
  },
  async reset(e) {
    const {u, auth: a} = await F();
    return u.sendPasswordResetEmail(a, e);
  },
  async signOut() {
    const {u, auth: a} = await F();
    return u.signOut(a);
  },
  // الصلاحية من Custom Claim (admin:true) يمنحها الخادم/Firebase CLI، وليس من الواجهة أو localStorage.
  async isAdmin() {
    if (!isLive()) return false;
    const {auth: a} = await F();
    const t = await a.currentUser?.getIdTokenResult(true);
    return !!t?.claims?.admin;
  }
};
