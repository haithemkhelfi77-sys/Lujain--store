import {CONFIG} from './config.js';
import * as S from './services.js';
const $=s=>document.querySelector(s),esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ST={new:'جديد',processing:'قيد المعالجة',confirmed:'تم التأكيد',shipping:'قيد الشحن',done:'مكتمل',cancelled:'ملغى'};
const toast=(m,t='ok')=>{const e=document.createElement('div');e.className='toast '+t;e.textContent=m;$('#toasts').append(e);setTimeout(()=>e.remove(),3200)};
const app=$('#app');
function login(msg=''){app.innerHTML=`<form class="login" id="lf"><h2>دخول الإدارة</h2>${msg?`<p class="warn-b">${msg}</p>`:''}<label>البريد<input name="e" type="email" required autocomplete="username"></label><label>كلمة المرور<input name="p" id="pw" type="password" required autocomplete="current-password"></label><button type="button" class="btn" id="sp">إظهار</button><button class="btn solid">دخول</button>${S.isLocalDev()&&!S.isLive()?'<button type="button" class="btn" id="pv">معاينة محلية (localhost فقط)</button>':''}</form>`;
 $('#sp').onclick=()=>{const p=$('#pw');p.type=p.type=='password'?'text':'password'};if($('#pv'))$('#pv').onclick=()=>panel(true);
 $('#lf').onsubmit=async e=>{e.preventDefault();if(!S.isLive())return toast('أضف إعدادات Firebase في js/config.js لتفعيل الدخول','warn');
  try{await S.auth.signIn(e.target.e.value,e.target.p.value);if(!await S.auth.isAdmin()){await S.auth.signOut();return toast('هذا الحساب لا يملك صلاحية المدير','err')}panel(false)}catch{toast('بيانات الدخول غير صحيحة','err')}}}
async function panel(preview=false){let tab='dash';const verifiedAdmin=!preview&&S.isLive()&&await S.auth.isAdmin();
 const draw=async()=>{const[P,O]=[await S.listProducts(true),await S.listOrders()];
 const low=P.filter(p=>p.stock<=CONFIG.lowStock),sales=O.filter(o=>o.status!='cancelled').reduce((a,o)=>a+o.total,0);
 const seedBtn=verifiedAdmin?'<button type="button" class="btn" id="seedCheck">فحص واستيراد SEED (demo0–demo7)</button>':'';
 let body='';
 if(tab=='dash')body=`<div class="stats"><div>المبيعات<b>${sales.toLocaleString('ar-DZ')}</b></div><div>الطلبات<b>${O.length}</b></div><div>المنتجات<b>${P.length}</b></div><div>طلبات جديدة<b>${O.filter(o=>o.status=='new').length}</b></div><div>مخزون منخفض<b>${low.length}</b></div></div>${P.some(p=>p.demo)?'<p class="warn-b">بعض المنتجات بيانات تجريبية فقط.</p>':''}`;
 if(tab=='prod')body=`<button class="btn solid" id="np">+ منتج جديد</button> ${seedBtn}<table class="tbl"><thead><tr><th>الاسم<th>السعر<th>المخزون<th>نشر<th></tr></thead>${P.map(p=>`<tr><td data-l="الاسم">${esc(p.name)}<td data-l="السعر">${p.price}<td data-l="المخزون"><input type="number" min="0" value="${p.stock}" data-stock="${p.id}" style="width:90px">${p.stock==0?' نفد':p.stock<=CONFIG.lowStock?' منخفض':''}<td data-l="نشر">${p.published?'نعم':'لا'}<td><button class="btn" data-edit="${p.id}">تعديل</button> <button class="btn" data-del="${p.id}">حذف</button></tr>`).join('')}</table><form id="pf" hidden></form>`;
 if(tab=='ord')body=O.length?`<table class="tbl"><thead><tr><th>الرقم<th>العميل<th>الهاتف<th>الإجمالي<th>الحالة</tr></thead>${O.map(o=>`<tr><td data-l="الرقم">${esc(o.id)}<td data-l="العميل">${esc(o.customer.name)}<td data-l="الهاتف">${esc(o.customer.phone)}<td data-l="الإجمالي">${o.total}<td data-l="الحالة"><select data-os="${o.id}">${Object.entries(ST).map(([k,v])=>`<option value="${k}" ${k==o.status?'selected':''}>${v}</option>`).join('')}</select></tr>`).join('')}</table>`:'<p class="empty">لا توجد طلبات بعد.</p>';
 app.innerHTML=`<div style="padding:4vw;max-width:1100px;margin:auto"><h2>لوحة الإدارة</h2>${preview?'<p class="warn-b">معاينة محلية بلا حماية — للتطوير فقط. في الإنتاج يلزم Firebase.</p>':''}<div class="tabs">${[['dash','الرئيسية'],['prod','المنتجات والمخزون'],['ord','الطلبات']].map(([k,v])=>`<button class="btn ${k==tab?'on':''}" data-t="${k}">${v}</button>`).join('')}</div>${body}</div>`;
 app.onclick=async e=>{const t=e.target,d=a=>t.dataset[a];if(d('t')){tab=d('t');draw()}
  if(t.id=='seedCheck'){if(!verifiedAdmin)return toast('غير مسموح بدون صلاحية admin حقيقية','err');
   try{const chk=await S.checkSeedConflicts();if(!chk.ok)return toast('وضع Firebase غير مفعّل','warn');
    let confirmOverwriteIds=[];
    if(chk.existingIds.length){const ok=confirm(`تنبيه: توجد مستندات موجودة مسبقاً بالمعرّفات التالية:
${chk.existingIds.join(', ')}

هل توافق على استبدال بيانات هذه المستندات الموجودة فقط؟ (إلغاء = استيراد غير الموجود فقط)`);
     if(ok)confirmOverwriteIds=chk.existingIds;}
    const res=await S.importSeedProducts({confirmOverwriteIds});
    toast(`تم استيراد ${res.imported.length} منتج؛ تم تخطي ${res.skippedExisting.length} موجود`);draw()}catch(err){toast(err.message||'تعذّر الاستيراد','err')}}
  if(d('del')&&confirm('حذف المنتج نهائياً؟')){await S.deleteProduct(d('del'));toast('تم الحذف');draw()}
  if(t.id=='np'||d('edit')){const p=d('edit')?P.find(x=>x.id==d('edit')):{name:'',cat:'',price:0,sale:0,stock:0,published:true,c1:'#2b2f55',c2:'#c9a45c',rating:4.5,created:Date.now(),desc:''};const f=$('#pf');f.hidden=false;
   f.innerHTML=`<label>الاسم<input name="name" required value="${esc(p.name)}"></label><label>التصنيف<input name="cat" required value="${esc(p.cat)}"></label><label>السعر<input name="price" type="number" min="1" required value="${p.price}"></label><label>سعر الخصم (0 = بلا)<input name="sale" type="number" min="0" value="${p.sale}"></label><label>الكمية<input name="stock" type="number" min="0" required value="${p.stock}"></label><label>الوصف<input name="desc" value="${esc(p.desc)}"></label><label><span><input type="checkbox" name="published" ${p.published?'checked':''} style="width:auto"> منشور</span></label><button class="btn solid">حفظ</button>`;
   f.onsubmit=async ev=>{ev.preventDefault();const v=Object.fromEntries(new FormData(f));if(+v.sale>=+v.price&&+v.sale>0)return toast('سعر الخصم يجب أن يقل عن السعر','err');
    await S.saveProduct({...p,...v,price:+v.price,sale:+v.sale,stock:+v.stock,published:!!v.published,demo:false});toast('تم الحفظ');draw()}}};
 app.onchange=async e=>{const t=e.target;if(t.dataset.stock){const p=P.find(x=>x.id==t.dataset.stock);await S.saveProduct({...p,stock:Math.max(0,+t.value)});toast('تم تحديث المخزون');draw()}
  if(t.dataset.os){await S.setOrderStatus(t.dataset.os,t.value);toast('تم تحديث الحالة')}}};draw()}
(async()=>{login(S.isLive()?'':'Firebase غير مفعّل بعد؛ الدخول غير متاح.')})();
